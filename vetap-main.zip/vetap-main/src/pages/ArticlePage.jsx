
const ArticlePage = () => {
  return (
    <>
      Artikli
    </>
  )
};

export default ArticlePage;
