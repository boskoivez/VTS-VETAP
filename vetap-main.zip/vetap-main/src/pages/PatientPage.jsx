
const PatientPage = () => {
  return (
    <>
      Pacijenti
    </>
  )
};

export default PatientPage;
