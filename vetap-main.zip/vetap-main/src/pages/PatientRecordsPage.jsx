
const PatientRecordsPage = () => {
  return (
    <>
      Kartoni
    </>
  )
};

export default PatientRecordsPage;
