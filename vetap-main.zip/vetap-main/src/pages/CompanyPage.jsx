
const CompanyPage = () => {
  return (
    <>
      Firme
    </>
  )
};

export default CompanyPage;
