
const SuppliersPage = () => {
  return (
    <>
      Dobavljaci
    </>
  )
};

export default SuppliersPage;
