const AddNewOwner = () => {
    return (
      <>
        AddNewOwner
      </>
    )
  };
  
  export default AddNewOwner;
  