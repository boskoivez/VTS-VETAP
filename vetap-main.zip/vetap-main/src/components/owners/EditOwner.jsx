const EditOwner = () => {
    return (
      <>
        EditOwner
      </>
    )
  };
  
  export default EditOwner;
  