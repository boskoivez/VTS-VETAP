export const Role = {
    User : "user",
    Admin : "admin"
}